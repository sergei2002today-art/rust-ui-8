package com.rustui;

import net.minecraft.network.chat.Component;

public class RustTitleScreen extends RustMenuScreen {
    public RustTitleScreen() {
        super(Component.translatable("narrator.screen.title"), null, false, -1);
    }

    @Override
    protected void init() {
        addMainButtons();
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
