package com.rustui;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

public class RustNewsScreen extends RustMenuScreen {
    private static final String[][] SECTIONS = {
        {"Релиз мода", "Rust UI 1.0.0: меню, загрузка и настройки в стиле Rust."},
        {"Нашли баг?", "Пришлите описание или скриншот в Telegram: @Theceartart"},
        {"Автор мода", "PixelArt"},
        {"Модераторы", "@ChatKeeperBot, @La_felicita_ama_il_silenzio"},
        {"Разработчики других проектов", "@makpolo, @Crekapm"},
        {"Бета-тестеры", "@ASUS670, @Flywline, @snap"},
        {"Музыка", "Саундтрек Rust, Facepunch Studios"}
    };

    public RustNewsScreen(net.minecraft.client.gui.screens.Screen parent) {
        super(Component.literal("Новости и авторы"), parent, true, 2);
    }

    @Override
    protected void init() {
        addMainButtons();
        addBackButton();
    }

    @Override
    protected void renderContent(GuiGraphics g, int mouseX, int mouseY, long el) {
        int x = colX0() + 6;
        int maxW = Math.max(120, width - x - 36);
        g.drawString(font, RustTheme.bold("Новости и авторы"), x, 40, RustTheme.WHITE);
        g.fill(x, 52, x + 40, 54, RustTheme.RED);
        int y = 62;
        for (int i = 0; i < SECTIONS.length; i++) {
            float e = RustTheme.ease((el - 300 - i * 120) / 500f);
            if (e < 0.04f) { y += 25; continue; }
            g.drawString(font, RustTheme.bold(SECTIONS[i][0]), x, y, RustTheme.a(0xCD412B, e));
            y += 10;
            List<FormattedCharSequence> lines = font.split(Component.literal(SECTIONS[i][1]), maxW);
            for (FormattedCharSequence line : lines) {
                g.drawString(font, line, x, y, RustTheme.a(0xE6E6E6, e));
                y += 10;
            }
            y += 5;
        }
    }
}
