package com.rustui.mixin;

import com.rustui.RustTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.LevelLoadingScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelLoadingScreen.class)
public abstract class LevelLoadingScreenMixin extends Screen {
    protected LevelLoadingScreenMixin(Component t) { super(t); }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void rustui$render(GuiGraphics g, int mx, int my, float delta, CallbackInfo ci) {
        ServerData sd = Minecraft.getInstance().getCurrentServer();
        String title = (sd != null && sd.name != null && !sd.name.isEmpty())
                ? sd.name : "Загрузка мира";
        String info = sd != null && sd.ip != null ? sd.ip : "Одиночная игра";
        RustTheme.drawLoading(g, this.font, this.width, this.height, title, info,
                Component.literal("Подготовка мира"), true, this.children(), mx, my);
        ci.cancel();
    }
}
