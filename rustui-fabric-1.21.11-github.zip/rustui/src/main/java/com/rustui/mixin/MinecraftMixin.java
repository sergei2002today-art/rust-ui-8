package com.rustui.mixin;

import com.rustui.RustOptionsScreen;
import com.rustui.RustPauseScreen;
import com.rustui.RustTheme;
import com.rustui.RustTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen rustui$replaceScreen(Screen screen) {
        if (screen == null) return null;
        Class<?> c = screen.getClass();
        Minecraft mc = (Minecraft) (Object) this;

        if (c == TitleScreen.class) {
            return new RustTitleScreen();
        }
        if (c == PauseScreen.class) {
            RustTheme.vanillaPause = screen;
            if (RustTheme.bypassPause) {
                RustTheme.bypassPause = false;
                return screen;
            }
            if (mc.level != null) {
                return new RustPauseScreen();
            }
        }
        if (c == OptionsScreen.class) {
            if (RustTheme.bypassOptions) {
                RustTheme.bypassOptions = false;
                return screen;
            }
            // "Options" opened from the (vanilla) pause menu -> Rust-style settings
            if (mc.level != null && mc.screen instanceof PauseScreen) {
                return new RustOptionsScreen(mc.screen);
            }
        }
        return screen;
    }
}
