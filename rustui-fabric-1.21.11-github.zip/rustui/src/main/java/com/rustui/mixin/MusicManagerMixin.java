package com.rustui.mixin;

import net.minecraft.client.sounds.MusicManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Disables Minecraft's own menu/game music so only the Rust tracks play. */
@Mixin(MusicManager.class)
public class MusicManagerMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true, require = 0)
    private void rustui$noVanillaMusic(CallbackInfo ci) {
        ci.cancel();
    }
}
