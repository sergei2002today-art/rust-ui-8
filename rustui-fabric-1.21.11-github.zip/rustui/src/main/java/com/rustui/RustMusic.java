package com.rustui;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.sounds.*;
import net.minecraft.util.Util;

/**
 * Plays the bundled Rust tracks in random order. Each file already has a fade-in / fade-out baked in,
 * so a track fades away at its end and the next random one fades in. Playback uses the MUSIC sound
 * category, so the game's "Music" volume slider controls it.
 */
public final class RustMusic {
    private static final String[] NAMES = {
        "Safe Zone", "Descent", "Umbra", "Closed Circuit", "Fissure", "Spaces", "Legacy",
        "Summit", "Stranded", "Crest", "Repose", "Companion", "Armored"
    };
    private static final long[] DURATION_MS = {
        352700L, 225300L, 261200L, 182500L, 206900L, 258300L, 193900L,
        187600L, 246000L, 415600L, 212200L, 187700L, 132100L
    };

    private static final Random RNG = new Random();
    private static long nextStart;
    private static int last = -1;
    private static int current = -1;
    private static SoundInstance instance;

    private RustMusic() {}

    /** Name of the track that is playing (null before the first one starts). */
    public static String currentName() {
        return current < 0 ? null : NAMES[current];
    }

    public static void tick(Minecraft mc) {
        if (mc.getOverlay() != null) return; // resources still loading
        long now = Util.getMillis();
        if (nextStart == 0L) {
            nextStart = now + 2500L;
            return;
        }
        if (now < nextStart) return;

        var sounds = mc.getSoundManager();
        if (instance != null) {
            sounds.stop(instance);
            instance = null;
        }
        int i;
        do {
            i = RNG.nextInt(NAMES.length);
        } while (NAMES.length > 1 && i == last);

        var id = Screen.MENU_BACKGROUND.withPath(String.format("rustui.music.%02d", i + 1));
        instance = SimpleSoundInstance.forMusic(SoundEvent.createVariableRangeEvent(id));
        sounds.play(instance);
        last = i;
        current = i;
        nextStart = now + DURATION_MS[i] + 1500L;
    }
}
