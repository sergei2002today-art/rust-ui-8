package com.rustui;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
// wildcard imports: these classes changed packages between versions
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.player.*;
import net.minecraft.client.resources.*;
import net.minecraft.client.resources.sounds.*;
import net.minecraft.sounds.*;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Util;

public final class RustTheme {
    public static final int RED      = 0xFFCD412B;
    public static final int RED_HOT  = 0xFFE0553B;
    public static final int TEXT     = 0xFFE6E6E6;
    public static final int TEXT_DIM = 0xFF9A9A9A;
    public static final int WHITE    = 0xFFFFFFFF;
    public static final int BAR_BG   = 0xFF0A0A0A;

    // ---- backgrounds (assets/minecraft/textures/gui/rustui/bg_XX.png) ----
    private static final int BG_COUNT = 13, BG_W = 640, BG_H = 276;
    private static final String[] BG_PATHS = new String[BG_COUNT];
    static {
        for (int i = 0; i < BG_COUNT; i++) BG_PATHS[i] = String.format("textures/gui/rustui/bg_%02d.png", i);
    }
    private static final Random RNG = new Random();
    public static int menuBg = RNG.nextInt(BG_COUNT);
    private static int loadBg = RNG.nextInt(BG_COUNT);
    private static int tipStart = 0;

    private static final String[] TIPS = {
        "Совет: плавающие на океане бутылки указывают на место для погружения: внизу можно найти сокровища.",
        "Совет: стоя на месте или присев, ты стреляешь точнее.",
        "Совет: камень и руда чаще всего встречаются у скал, гор и утёсов.",
        "Совет: с обломков вертолёта и БТР можно собрать металл.",
        "Совет: колёсико мыши по предмету в быстром крафте добавляет в очередь сразу пять штук.",
        "Совет: правый клик по полосе разделения делит стопку на нужное количество.",
        "Совет: погрузись в воду и поплавай, чтобы смыть радиацию.",
        "Совет: ненужные вещи безопасно продаются через торговый автомат.",
        "Совет: нашёл ошибку в игре? Нажми F7, чтобы отправить отчёт.",
        "Совет: ломай бочки и ящики у дорог: в них часто лежит скрап и детали.",
        "Совет: поставь шкаф с инструментами первым делом: он защищает базу от чужих построек.",
        "Совет: повесь на дверь кодовый замок: обычный ключ легко потерять.",
        "Совет: спальный мешок задаёт точку возрождения. Разложи несколько в разных местах.",
        "Совет: чертежи из монументов изучаются на исследовательском столе.",
        "Совет: в монументах бывает радиация: бери костюм и препараты заранее.",
        "Совет: не бегай по открытой местности с ценной добычей: сначала спрячь её в ящик.",
        "Совет: лодка быстрее бега, но шум мотора слышно очень далеко.",
        "Совет: одежда защищает от холода: следи за температурой, особенно ночью.",
        "Совет: шприцы лечат мгновенно, но их нужно носить с собой.",
        "Совет: делай базу с несколькими комнатами и держи ценное подальше от входа.",
        "Совет: огонь костра согревает, но дым выдаёт твоё местоположение.",
        "Совет: перед входом в монумент перезарядись и проверь запас патронов.",
        "Совет: разбирай ненужные предметы на компоненты: из них собирается новая экипировка.",
        "Совет: игрок без оружия может быть новичком: не всегда стоит стрелять первым.",
        "Совет: в голосовом чате слышны только те, кто рядом. Держи друзей поближе.",
        "Совет: ночью темно, и факел виден издалека. Выбирай между светом и скрытностью.",
        "Совет: лучшая защита от рейда — база, о которой никто не знает.",
        "Совет: стрелы летят по дуге: целься выше на большой дистанции.",
        "Совет: запасайся едой и водой заранее: голод и жажда подкрадываются незаметно.",
        "Совет: держи оружие заряженным, а друзей поближе."
    };
    private static final String[] DOTS = {"", ".", "..", "..."};

    /** set right before opening the vanilla OptionsScreen so the mixin does not swap it again */
    public static boolean bypassOptions;
    /** the real (vanilla) pause screen instance, and a flag to let it open without being replaced */
    public static boolean bypassPause;
    public static Screen vanillaPause;

    private static long loadStart, lastLoad;
    private static float cancelHover;
    private static long cancelLast;

    // ---- embers: constants precomputed once ----
    private static final int EMBERS = 40;
    private static final double[] E_FX = new double[EMBERS], E_SPEED = new double[EMBERS], E_PHASE = new double[EMBERS];
    static {
        for (int i = 0; i < EMBERS; i++) {
            E_FX[i] = (i * 0.6180339887) % 1.0;
            E_SPEED[i] = 10 + (i % 7) * 4;
            E_PHASE[i] = (i * 0.37) % 1.0;
        }
    }

    private static final Map<String, Component> BOLD = new HashMap<>();

    private RustTheme() {}

    // ---------- helpers ----------
    /** Cached upper-case bold component (avoids per-frame allocations). */
    public static Component bold(String s) {
        Component c = BOLD.get(s);
        if (c == null) {
            if (BOLD.size() > 256) BOLD.clear();
            c = Component.literal(s.toUpperCase(Locale.ROOT)).withStyle(st -> st.withBold(true));
            BOLD.put(s, c);
        }
        return c;
    }

    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float u = 1f - t;
        return 1f - u * u * u;
    }

    /** rgb (no alpha) + alpha 0..1 -> ARGB */
    public static int a(int rgb, float alpha) {
        int al = (int) (Math.max(0f, Math.min(1f, alpha)) * 255f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    // ---------- background pieces ----------
    /** Draws a Rust photo scaled to cover the whole screen. */
    public static void drawPhoto(GuiGraphics g, int w, int h, int idx) {
        var id = Screen.MENU_BACKGROUND.withPath(BG_PATHS[idx]);
        float s = Math.max(w / (float) BG_W, h / (float) BG_H);
        int dw = (int) Math.ceil(BG_W * s), dh = (int) Math.ceil(BG_H * s);
        g.blit(RenderPipelines.GUI_TEXTURED, id, (w - dw) / 2, 0, 0f, 0f, dw, dh, BG_W, BG_H, BG_W, BG_H);
    }

    public static void drawEmbers(GuiGraphics g, int w, int h) {
        double t = Util.getMillis() / 1000.0;
        double cycle = h + 30;
        for (int i = 0; i < EMBERS; i++) {
            double y = h + 10 - ((t * E_SPEED[i] + E_PHASE[i] * cycle) % cycle);
            double x = E_FX[i] * w + Math.sin(t * 0.7 + i) * 12;
            float life = (float) Math.min(1.0, Math.max(0.0, (h + 10 - y) / cycle));
            float alpha = (float) Math.sin(Math.PI * life) * 0.85f;
            int s = (i % 3 == 0) ? 2 : 1;
            g.fill((int) x, (int) y, (int) x + s, (int) y + s, a((i % 4 == 0) ? 0xFF8A2B : 0xCD412B, alpha));
        }
    }

    public static void drawVignette(GuiGraphics g, int w, int h) {
        for (int i = 0; i < 20; i++) {
            int c = ((int) (0xB0 * (1f - i / 20f))) << 24;
            g.fill(i * 6, 0, i * 6 + 6, h, c);
            g.fill(w - i * 6 - 6, 0, w - i * 6, h, c);
        }
    }

    public static void drawLeftShade(GuiGraphics g, int h) {
        for (int i = 0; i < 30; i++) {
            int c = ((int) (0x98 * (1f - i / 30f))) << 24;
            g.fill(i * 10, 0, i * 10 + 10, h, c);
        }
    }

    /** Soft fog band: feathered on all four sides (no hard edges). */
    private static void fogBand(GuiGraphics g, int x, int y1, int bandW, int y2, int maxAlpha) {
        int n = 12, sw = Math.max(1, bandW / n), mid = (y1 + y2) / 2;
        for (int k = 0; k < n; k++) {
            int al = (int) (maxAlpha * Math.sin(Math.PI * (k + 0.5) / n));
            int c = (al << 24) | 0xC8D2D8;
            g.fillGradient(x + k * sw, y1, x + (k + 1) * sw, mid, 0x00C8D2D8, c);
            g.fillGradient(x + k * sw, mid, x + (k + 1) * sw, y2, c, 0x00C8D2D8);
        }
    }

    public static void drawFog(GuiGraphics g, int w, int h) {
        double t = Util.getMillis() / 1000.0;
        fogBand(g, (int) ((Math.sin(t * 0.12) * 0.25 - 0.05) * w), (int) (h * 0.25), (int) (w * 0.9), (int) (h * 0.80), 0x16);
        fogBand(g, (int) ((Math.cos(t * 0.09) * 0.25 + 0.25) * w), (int) (h * 0.45), (int) (w * 0.8), (int) (h * 0.98), 0x10);
    }

    /** Background used by the title screen. */
    public static void drawTitleBackground(GuiGraphics g, int w, int h) {
        if (Minecraft.getInstance().level != null) {
            // in-game: keep the world visible, just darken it
            g.fillGradient(0, 0, w, h, 0xB0101010, 0xE0000000);
        } else {
            drawPhoto(g, w, h, menuBg);
            g.fill(0, 0, w, h, 0x66000000);
            drawFog(g, w, h);
        }
        drawLeftShade(g, h);
        drawVignette(g, w, h);
        drawEmbers(g, w, h);
    }

    /** Background used by every other screen (via ScreenMixin). */
    public static void drawMenuBackground(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            drawPhoto(g, w, h, menuBg);
            g.fill(0, 0, w, h, 0xB4000000);
            drawFog(g, w, h);
            drawVignette(g, w, h);
            drawEmbers(g, w, h);
        } else {
            cachedSkin = mc.player.getSkin();
            g.fillGradient(0, 0, w, h, 0xC8101010, 0xE6000000);
        }
        // Rust logo on every vanilla menu screen too (pause menu, settings sub-screens, ...)
        drawLogo(g, mc.font, 28, 46, 1f);
    }

    private static final String[][] LETTERS = {
        {"11110", "11011", "11011", "11110", "11101", "11011", "11011"}, // R
        {"11011", "11011", "11011", "11011", "11011", "11011", "01110"}, // U
        {"01111", "11000", "11000", "01110", "00011", "00011", "11110"}, // S
        {"11111", "01110", "01110", "01110", "01110", "01110", "01110"}  // T
    };

    private static final String[][] ICONS = {
        {"0011100", "0111110", "0011100", "0000000", "0111110", "1111111", "1111111"}, // avatar
        {"0011100", "0111110", "1101011", "1111111", "1101011", "0111110", "0011100"}, // globe
        {"1111111", "1000001", "1011101", "1000001", "1111111", "0011000", "0010000"}, // chat
        {"0001000", "0001000", "1111111", "0111110", "0011100", "0110110", "1100011"}, // star
        {"0011100", "0110110", "1100011", "1111111", "1100011", "1100011", "1100011"}  // A
    };

    private static void drawBitmap(GuiGraphics g, String[] rows, int x, int y, int cell, int color) {
        for (int r = 0; r < rows.length; r++) {
            String row = rows[r];
            for (int c = 0; c < row.length(); c++) {
                if (row.charAt(c) == '1') g.fill(x + c * cell, y + r * cell, x + c * cell + cell, y + r * cell + cell, color);
            }
        }
    }

    /** Logo: custom icon image (textures/gui/rustui/logo.png) + blocky white RUST letters. */
    public static void drawLogo(GuiGraphics g, Font font, int x, int y, float appear) {
        if (appear < 0.04f) return;
        x -= (int) (20 * (1f - appear));
        int icon = 30;
        var id = Screen.MENU_BACKGROUND.withPath("textures/gui/rustui/logo.png");
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, icon, icon, 64, 64, 64, 64);
        int white = a(0xFFFFFF, appear);
        int lx = x + icon + 8;
        int ly = y + (icon - 21) / 2;
        for (String[] letter : LETTERS) {
            drawBitmap(g, letter, lx, ly, 3, white);
            lx += 5 * 3 + 3;
        }
    }

    /** Decorative icon column on the right (like the Rust menu). */
    public static void drawSideIcons(GuiGraphics g, int w, float appear) {
        if (appear < 0.04f) return;
        for (int i = 1; i < ICONS.length; i++) {
            float e = ease(appear * 1.6f - i * 0.15f);
            if (e < 0.04f) continue;
            drawBitmap(g, ICONS[i], w - 26, 56 + i * 20, 2, a(0xB4B4B4, e * 0.85f));
        }
    }

    // ---------- player head (top-right) ----------
    private static Object cachedSkin;

    @SuppressWarnings("unchecked")
    private static <T> T cast(Object o) { return (T) o; }

    public static void drawHead(GuiGraphics g, int w, float appear) {
        if (appear < 0.04f) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) cachedSkin = mc.player.getSkin();
        int size = 20, x = w - 32, y = 46;
        g.fill(x - 2, y - 2, x + size + 2, y + size + 2, a(0x000000, 0.55f * appear));
        g.fill(x - 2, y + size, x + size + 2, y + size + 2, a(0xCD412B, appear));
        if (cachedSkin != null) {
            PlayerFaceRenderer.draw(g, RustTheme.cast(cachedSkin), x, y, size);
        } else {
            PlayerFaceRenderer.draw(g, DefaultPlayerSkin.get(mc.getUser().getProfileId()), x, y, size);
        }
    }

    // ---------- UI sounds (vanilla sound, tuned) ----------
    public static void playHover() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.9f, 0.35f));
    }

    public static void playClick() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 0.65f, 0.8f));
    }

    // ---------- loading screen ----------
    private static void drawLoadingBar(GuiGraphics g, int w, int h, long el, float frac) {
        int y = h - 4;
        g.fill(0, y, w, h, BAR_BG);
        if (frac >= 0f) {
            int head = (int) (w * Math.min(1f, frac));
            g.fill(0, y, head, h, RED);
            for (int k = 0; k < 8; k++) {
                int x0 = head - k * 5 - 5;
                if (x0 < 0) break;
                g.fill(x0, y, x0 + 5, h, a(0xFF7A5C, 0.5f * (1f - k / 8f)));
            }
            return;
        }
        float p = (el % 2400L) / 2400f;
        float e = p * p * (3f - 2f * p);
        int head = (int) (e * (w + 200));
        for (int k = 0; k < 20; k++) {
            int x0 = head - k * 8 - 8;
            int x1 = x0 + 8;
            if (x1 <= 0 || x0 >= w) continue;
            g.fill(Math.max(0, x0), y, Math.min(w, x1), h, a(k == 0 ? 0xE0553B : 0xCD412B, 1f - k / 20f));
        }
    }

    public static void drawLoading(GuiGraphics g, Font font, int w, int h, String title, String info,
                                   Component sub, boolean counter, List<? extends GuiEventListener> children, int mx, int my) {
        long now = Util.getMillis();
        if (now - lastLoad > 800L) {
            loadStart = now;
            loadBg = RNG.nextInt(BG_COUNT);
            tipStart = RNG.nextInt(TIPS.length);
        }
        lastLoad = now;
        long el = now - loadStart;

        drawPhoto(g, w, h, loadBg);
        g.fill(0, 0, w, h, 0x40000000);
        drawFog(g, w, h);
        g.fillGradient(0, h - 150, w, h, 0x00000000, 0xF8000000);
        drawVignette(g, w, h);
        drawEmbers(g, w, h);

        float in = ease(el / 600f);
        int slide = (int) (40 * (1f - in));
        if (in > 0.04f) g.drawString(font, bold(title), 28 - slide, h - 96, a(0xFFFFFF, in));
        float in2 = ease((el - 150) / 600f);
        if (in2 > 0.04f) g.drawString(font, Component.literal(info), 28 - slide, h - 82, a(0x9A9A9A, in2));

        // fake-but-smooth territory counter 1 .. 10000 (the real progress is not exposed by the game)
        float frac = -1f;
        Component subDraw = sub;
        if (counter) {
            int n = 1 + (int) (9998 * (1.0 - Math.exp(-el / 3500.0)));
            n = Math.min(9999, n);
            frac = n / 10000f;
            subDraw = Component.literal("Загрузка ресурсов (" + n + "/10000)");
            if (in2 > 0.04f) {
                g.drawString(font, Component.literal("Загрузка ресурсов: " + n + " / 10000"),
                        28 - slide, h - 62, a(0xE6E6E6, in2));
            }
        }

        Component full = bold("Загрузка...");
        int statusW = Math.max(font.width(full), font.width(subDraw));
        int cancelX = w - 24 - statusW - 12 - 96;

        long period = 4500L;
        int idx = (int) ((tipStart + el / period) % TIPS.length);
        long ph = el % period;
        float fade = Math.min(1f, Math.min(ph / 400f, (period - ph) / 400f)) * in;
        double t = now / 1000.0;
        float badge = (float) (0.75 + 0.25 * Math.sin(t * 3.0));
        g.fill(28, h - 41, 38, h - 31, a(0xFFFFFF, badge * in));
        if (in > 0.04f) g.drawString(font, Component.literal("i"), 32, h - 40, 0xFF000000);
        if (fade > 0.04f) {
            int maxW = Math.max(80, cancelX - 44 - 10);
            List<FormattedCharSequence> lines = font.split(Component.literal(TIPS[idx]), maxW);
            for (int i = 0; i < Math.min(3, lines.size()); i++) {
                g.drawString(font, lines.get(i), 44, h - 40 + i * 10, a(0x9A9A9A, fade));
            }
        }

        int lx = w - 24 - font.width(full);
        g.drawString(font, bold("Загрузка" + DOTS[(int) ((now / 400L) % 4)]), lx, h - 46, WHITE);
        g.drawString(font, subDraw, w - 24 - font.width(subDraw), h - 34, TEXT_DIM);

        for (GuiEventListener c : children) {
            if (c instanceof AbstractWidget wd) {
                wd.setWidth(96);
                wd.setX(cancelX);
                wd.setY(h - 50);
                int x = wd.getX(), y = wd.getY(), bw = wd.getWidth(), bh = wd.getHeight();
                boolean hot = mx >= x && mx < x + bw && my >= y && my < y + bh;
                float dt = cancelLast == 0 ? 16f : Math.min(100f, now - cancelLast);
                cancelLast = now;
                cancelHover += ((hot ? 1f : 0f) - cancelHover) * Math.min(1f, dt / 80f);
                g.fill(x, y, x + bw, y + bh, RED);
                g.fill(x, y, x + (int) (bw * cancelHover), y + bh, RED_HOT);
                Component label = bold(wd.getMessage().getString());
                g.drawString(font, label, x + (bw - font.width(label)) / 2, y + (bh - 8) / 2, WHITE);
            }
        }

        drawLoadingBar(g, w, h, el, frac);

        float black = 1f - ease(el / 500f);
        if (black > 0.01f) g.fill(0, 0, w, h, a(0x000000, black));
    }
}
