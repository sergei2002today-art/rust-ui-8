package com.rustui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

/** Shared shell: background, logo, player head, icons and the left main menu. */
public abstract class RustMenuScreen extends Screen {
    protected static final int BASE_X = 18;
    protected final long openTime = Util.getMillis();
    protected final List<RustButton> buttons = new ArrayList<>();
    protected final Screen parent;
    private final boolean compact;
    private final int selected;

    protected RustMenuScreen(Component title, Screen parent, boolean compact, int selected) {
        super(title);
        this.parent = parent;
        this.compact = compact;
        this.selected = selected;
    }

    /** The title screen (root of the menu tree). */
    protected Screen root() { return parent == null ? this : parent; }

    protected int colX0() { return Math.max(148, (int) (width * 0.235)); }
    protected int colX1() { return colX0() + Math.max(100, (int) (width * 0.17)); }
    protected int contentX() { return colX1() + 22; }

    private void addMain(int idx, double frac, int w, Component label, Button.OnPress press) {
        RustButton b = new RustButton(BASE_X, (int) (height * frac), w, 16, label, b2 -> {
            RustTheme.playClick();
            press.onPress(b2);
        });
        b.selected = idx == selected;
        buttons.add(b);
        addRenderableWidget(b);
    }

    protected boolean inWorld() { return minecraft != null && minecraft.level != null; }

    protected void addMainButtons() {
        buttons.clear();
        int w = compact ? 122 : 176;
        boolean world = inWorld();
        if (world) {
            // in-game (Esc) variant
            addMain(0, 0.353, w, Component.literal("Вернуться в игру"),
                    b -> minecraft.setScreen(null));
        } else {
            addMain(0, 0.353, w, Component.translatable("menu.singleplayer"),
                    b -> minecraft.setScreen(new SelectWorldScreen(this)));
            addMain(1, 0.462, w, Component.translatable("menu.multiplayer"),
                    b -> minecraft.setScreen(new JoinMultiplayerScreen(this)));
        }
        // clicking the highlighted item again closes the page and returns to the lobby / pause menu
        addMain(2, 0.560, w, Component.literal("Новости и авторы"),
                b -> minecraft.setScreen(selected == 2 ? parent : new RustNewsScreen(root())));
        addMain(3, 0.756, w, Component.translatable("menu.options"),
                b -> minecraft.setScreen(selected == 3 ? parent : new RustOptionsScreen(root())));
        if (world) {
            addMain(4, 0.868, w, Component.literal("Выход из мира..."),
                    b -> {
                        // opens the real pause menu, where "Save and quit" lives
                        RustTheme.bypassPause = true;
                        minecraft.setScreen(RustTheme.vanillaPause);
                    });
        } else {
            addMain(4, 0.868, w, Component.translatable("menu.quit"),
                    b -> minecraft.stop());
        }
    }

    /** "< Назад" at the bottom of the red column: returns to the lobby (or pause menu). */
    protected void addBackButton() {
        RustCatButton b = new RustCatButton(colX0(), height - 30, colX1() - colX0(), 18,
                Component.literal("< Назад"), x -> {
                    RustTheme.playClick();
                    minecraft.setScreen(parent);
                });
        addRenderableWidget(b);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long el = Util.getMillis() - openTime;
        for (int i = 0; i < buttons.size(); i++) {
            float e = RustTheme.ease((el - 250 - i * 110) / 500f);
            RustButton b = buttons.get(i);
            b.appear = e;
            b.setX(BASE_X - (int) (36 * (1f - e)));
        }
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long el = Util.getMillis() - openTime;
        RustTheme.drawTitleBackground(g, width, height);
        // y=46 keeps the logo under the launcher's on-screen Esc button
        RustTheme.drawLogo(g, font, 28, 46, RustTheme.ease(el / 700f));
        float ic = RustTheme.ease((el - 500) / 900f);
        RustTheme.drawHead(g, width, ic);
        RustTheme.drawSideIcons(g, width, ic);
        String track = RustMusic.currentName();
        if (track != null) {
            g.drawString(font, Component.literal("Музыка: " + track), 28, height - 14, RustTheme.a(0x9A9A9A, RustTheme.ease((el - 800) / 800f)));
        }
        renderContent(g, mouseX, mouseY, el);
        float black = 1f - RustTheme.ease(el / 450f);
        if (black > 0.01f) g.fill(0, 0, width, height, RustTheme.a(0x000000, black));
    }

    /** Sub-screens draw their panels/text here. */
    protected void renderContent(GuiGraphics g, int mouseX, int mouseY, long el) {}

    @Override
    public void onClose() {
        if (parent != null) minecraft.setScreen(parent);
        else super.onClose();
    }
}
