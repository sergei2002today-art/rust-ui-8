package com.rustui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Category entry inside the red column of the settings screen (right-aligned text). */
public class RustCatButton extends Button {
    public boolean selected;
    private boolean wasHot;

    public RustCatButton(int x, int y, int w, int h, Component label, OnPress onPress) {
        super(x, y, w, h, label, onPress, DEFAULT_NARRATION);
    }

    @Override
    public void renderContents(GuiGraphics g, int mouseX, int mouseY, float delta) {
        boolean hot = this.isHoveredOrFocused();
        if (hot && !wasHot) RustTheme.playHover();
        wasHot = hot;
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        if (selected) g.fill(x, y, x + w, y + h, RustTheme.a(0xFFFFFF, 0.20f));
        else if (hot) g.fill(x, y, x + w, y + h, RustTheme.a(0xFFFFFF, 0.09f));
        var font = Minecraft.getInstance().font;
        Component c = RustTheme.bold(getMessage().getString());
        g.drawString(font, c, x + w - 8 - font.width(c), y + (h - 8) / 2,
                RustTheme.a(0xFFFFFF, (selected || hot) ? 1f : 0.82f));
    }
}
