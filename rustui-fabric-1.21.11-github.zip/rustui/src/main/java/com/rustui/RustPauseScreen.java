package com.rustui;

import net.minecraft.network.chat.Component;

/** In-game Esc menu in the Rust style (replaces the vanilla pause screen). */
public class RustPauseScreen extends RustMenuScreen {
    public RustPauseScreen() {
        super(Component.literal("Пауза"), null, false, -1);
    }

    @Override
    protected void init() {
        addMainButtons();
    }

    @Override
    public void onClose() {
        minecraft.setScreen(null);
    }
}
