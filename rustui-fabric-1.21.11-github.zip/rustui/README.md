# Rust UI (Fabric 1.21.11, client-only)
Build: install JDK 21, then in this folder run `gradle wrapper --gradle-version 9.2` once (or copy gradlew/gradle/wrapper from the Fabric example mod), then `./gradlew build`.
Jar: build/libs/rustui-1.0.0.jar
Check versions at https://fabricmc.net/develop if gradle.properties versions are not found.
